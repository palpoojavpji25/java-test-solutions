public class SecondLargest {
    public static int findSecondLargest(int[] nums) {
        if (nums.length < 2) {
            System.out.println("Array should have at least two elements");
            return Integer.MIN_VALUE;
        }
        
        int max = nums[0];
        int secondMax = Integer.MIN_VALUE;
        
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] > max) {
                secondMax = max;
                max = nums[i];
            } else if (nums[i] > secondMax && nums[i] != max) {
                secondMax = nums[i];
            }
        }
        
        if (secondMax == Integer.MIN_VALUE) {
            System.out.println("All elements are same in the array");
            return Integer.MIN_VALUE;
        }
        
        return secondMax;
    }

    public static void main(String[] args) {
        int[] nums = {10, 5, 20, 5, 30, 30, 10};
        int secondLargest = findSecondLargest(nums);
        System.out.println("Second largest element: " + secondLargest);
    }
}


