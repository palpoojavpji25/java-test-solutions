public class NumberOfDigits {
    public static void main(String[] args) {
        int num = 34987; // Example number
        int count = String.valueOf(num).length();
        System.out.println(count);
    }
}

